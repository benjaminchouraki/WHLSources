from pyspark.sql.functions import lit, to_timestamp, to_date, current_timestamp, sha2, concat_ws, input_file_name, explode, split, regexp_extract
from pyspark.sql.types import LongType


def stringToTimeStamp(df, columnName, inputformat):
    return df.withColumn(columnName, to_timestamp(columnName,inputformat))

def stringToLong(df, columnName):
    return df.withColumn(columnName, df[columnName].cast(LongType()))

def addHashKey(df):
    return df.withColumn("hashkey", sha2(concat_ws("||", *df.columns), 256))

def addOriginalFileName(df):
    df = df.withColumn("OriginalFileName", input_file_name())
    return extractParentFolder(df, "OriginalFileName")

def addLoadDate(df):
    return df.withColumn("LoadDate",current_timestamp())

def extractParentFolder(df, PathColumn):
    regex_str = "[\/]([^\/]+[\/][^\/]+)$"
    df = df.withColumn(PathColumn, regexp_extract(df[PathColumn],regex_str,1))
    
    return df

def explodeJSONArray(df, ArrayField):
    df = df.withColumn("Rows", explode(df[ArrayField])) \
                    .drop("Name") \
                    .select("Rows.*")
    return df