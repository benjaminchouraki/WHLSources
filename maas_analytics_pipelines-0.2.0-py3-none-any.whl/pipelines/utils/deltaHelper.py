
from pipelines.utils.fileHelper import checkFolderExists, saveDF

def generateMergeStatement(Database, SourceTable, DestTable, IDcolumns):
  #variables initialization
  mergeClause = ""
  index = 0
  
  #split columns list and generate merge clause
  for column in IDcolumns.split(','):
    if index > 0:
      mergeClause = mergeClause + " AND "
      
    mergeClause = mergeClause + "Source.{IDSrc} = Dest.{IDDest}".format(IDSrc=column, IDDest = column)
    index = index + 1
  #end split
  
  MergeStatement = "MERGE INTO {DATABASE}.{TABLE} as Dest USING {TEMP_TABLE} as Source ON {MERGE_CLAUSE} WHEN MATCHED AND Source.hashkey <> Dest.hashkey THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *".format(DATABASE=Database,TEMP_TABLE=SourceTable,TABLE=DestTable,MERGE_CLAUSE=mergeClause)
  
  return MergeStatement
 

def createTable(spark, database, table, location):
    spark.sql("CREATE DATABASE IF NOT EXISTS " + database)
    spark.sql(""" CREATE TABLE IF NOT EXISTS {DATABASE}.{TABLE} USING DELTA LOCATION "{PATH}" """.format(DATABASE=database,TABLE=table,PATH=location))

def MergeDF(spark, df, database, table, location, keys):
    temp_table = "TEMP_" + table
    df.createOrReplaceTempView(temp_table)
    
    if checkFolderExists(location) == False:
        saveDF(df, filename=location,source=table)
        createTable(spark, database, table, location)
    else:
        createTable(spark, database, table, location)
        mergeStatement = generateMergeStatement(database, temp_table, table,keys)
        spark.sql(mergeStatement)