
import os
from pyspark.sql.functions import explode


def checkFileExists(path):
    return os.path.isfile(path)

def checkFolderExists(path):
    return os.path.isdir(path)

def extractCSVFile(spark, filename, schema, format, delimiter):
    df = spark.read \
                .format(format) \
                .option("delimiter", delimiter) \
                .option("encoding", "ISO-8859-1") \
                .schema(schema) \
                .load(filename, header=True)

    return df

def extractJSONFile(spark, filename, schema):
    df = spark.read \
                .format("json") \
                .schema(schema) \
                .option("multiline",True) \
                .option("mode","DROPMALFORMED") \
                .load(filename)
    return df


def getTargetFormat(datasource):
    return "delta"

def saveDF(df, filename, source):
    datasourceFormat = getTargetFormat(source)
    df.write.format(datasourceFormat).mode("overwrite").save(filename,header=True)
    