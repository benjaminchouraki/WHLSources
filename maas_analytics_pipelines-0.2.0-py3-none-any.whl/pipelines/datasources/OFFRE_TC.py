from pyspark.sql.functions import explode, split, regexp_replace, regexp_extract, udf, input_file_name, first
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pipelines.utils.configmanagement import getDatasourcesConfig
from pipelines.utils.fileHelper import saveDF, extractCSVFile
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName


def define_Structures():
    #region Arrets
    global schemaArret
    global schemArretLigne
    global schemaArretAttribut
    global schemaAL_AR
    global schemaArretLogique

    schemaArret = StructType(
    [
        
        StructField("Code", StringType(), False),
        StructField("Nom", StringType(), False),
        StructField("Description", StringType(), False),
        StructField("Type", StringType(), False),
        StructField("NomArrGen", StringType(), False),
        StructField("X", StringType(), False),
        StructField("Y", StringType(), False),
        StructField("Commune", StringType(), False),
        StructField("Insee", StringType(), False),
        StructField("Commentaire", StringType(), False),    
        StructField("IDAP", IntegerType(), False)
    ]
    )
    schemArretLigne = StructType(
    [
        StructField("Code ligne", StringType(), False),
        StructField("Sens", IntegerType(), False),
        StructField("Numero Ordre", IntegerType(), False),
        StructField("Code arret", StringType(), False),
        StructField("Identifiant arret", IntegerType(), False),
        StructField("CodeVersion", IntegerType(), False)
    ]
    )
    schemaArretAttribut = StructType(
    [
        StructField("IDAP", IntegerType(), False),
        StructField("Nom", StringType(), False),
        StructField("Valeur", StringType(), False)
    ]
    )
    schemaAL_AR = StructType(
    [
        StructField("IDAP", IntegerType(), False),
        StructField("ALCODE", StringType(), False)
    ]
    )
    schemaArretLogique = StructType(
    [
        StructField("ALCODE", IntegerType(), False),
        StructField("NOM", StringType(), False)
    ]
    )
    #endregion

    #region Lignes
    global schemaDirection
    global schemaLigne
    global schemaLigneVersion
    global schemaReseau
    global schemaTransporteur
    global schemaModeTransport
    global schemaGroupeLigne


    schemaDirection = StructType(
    [
        StructField("Direction", StringType(), False),
        StructField("Ligne", StringType(), False),
        StructField("Sens", IntegerType(), False),
        StructField("Chemin", StringType(), False),
        StructField("CodeLigneVersion", IntegerType(), False),
    ]
    )

    schemaLigne = StructType(
    [
        StructField("CodeLigne", StringType(), False),
        StructField("CodeCom", StringType(), False),
        StructField("Libelle", StringType(), False),
        StructField("CodeRepresentation", StringType(), False),
        StructField("CodeSousTraitant", StringType(), False),
        StructField("Transporteur", StringType(), False),
        StructField("Reseau", StringType(), False),
        StructField("GroupeLigne", StringType(), False),
        StructField("CodeCom2", IntegerType(), False),       
        StructField("IDLI", StringType(), False),
        StructField("CodeLigneVersion", IntegerType(), False),

    ]
    )

    schemaLigneVersion = StructType(
    [
        StructField("CodeVersion", IntegerType(), False),
        StructField("CodeLigne", StringType(), False),
        StructField("DateDebutValidite", StringType(), False),
        StructField("DateFinValidite", StringType(), False)
    ]
    )

    schemaModeTransport = StructType(
    [
        StructField("ModeLibelle", StringType(), False),
        StructField("Designation", StringType(), False),
        StructField("Ligne", StringType(), False)
    ]
    )

    schemaReseau = StructType(
    [
        StructField("Code", StringType(), False),
        StructField("Nom", StringType(), False),
        StructField("IDRES", IntegerType(), False)
    ]
    )

    schemaTransporteur = StructType(
    [
        StructField("Code", StringType(), False),
        StructField("Nom", StringType(), False),
        StructField("IDTR", StringType(), False)
    ]
    )

    schemaGroupeLigne = StructType(
    [
        StructField("Code", StringType(), False),
        StructField("Nom", StringType(), False),
        StructField("IDGL", StringType(), False)
    ]
    )
    #endregion

    #region Chemins
    global schemaChemin
    global schemaCheminArret
    global schemaShape
    
    schemaChemin = StructType(
    [
        StructField('Ligne', StringType(), True),
        StructField('Chemin', StringType(), True),
        StructField('IDCH', IntegerType(), True),
        StructField('CodeClient', StringType(), True),
        StructField('Sens', StringType(), True),
        StructField('Type', StringType(), True),
        StructField('ShapeId', StringType(), True),
        StructField('CodeLigneVersion', IntegerType(), True),
        StructField('DebutValidite', StringType(), True),
        StructField('FinValidite', StringType(), True)
    ]
    )

    schemaCheminArret = StructType(
    [
        StructField('CodeLig', StringType(), True),
        StructField('CodeChemin', StringType(), True),
        StructField('Sens', IntegerType(), True),
        StructField('NumOrdreArret', IntegerType(), True),
        StructField('CodeArret', StringType(), True),
        StructField('IdArret', IntegerType(), True),
        StructField('Distance', StringType(), True),
        StructField('TypeArret', IntegerType(), True),
        StructField('CodeLigneVersion', IntegerType(), True)
    ]
    )

    schemaShape = StructType(
    [
        StructField('shape_id', StringType(), True),
        StructField('latitude', StringType(), True),
        StructField('longitude', StringType(), True),
        StructField('numero_ordre', IntegerType(), True),
        StructField('distance', IntegerType(), True),
        StructField('ptano', IntegerType(), True),
        StructField('aitordre', IntegerType(), True)
    ]
    )

    #endregion

    #region Courses
    global schemaCourse
    global schemaCourseDate

    schemaCourse = StructType(
    [
        StructField('Numero', IntegerType(), True),
        StructField('ServiceVoiture', StringType(), True),
        StructField('TypeMateriel', StringType(), True),
        StructField('NomReduitArret', StringType(), True),
        StructField('Heure', StringType(), True),
        StructField('Ligne', StringType(), True),
        StructField('Chemin', StringType(), True),
        StructField('Type', StringType(), True),
        StructField('Sens', IntegerType(), True),
        StructField('Validite', IntegerType(), True),
        StructField('IdGraph', StringType(), True),
        StructField('IDAP', IntegerType(), True),
        StructField('Renvois', StringType(), True),
        StructField('Periodes', StringType(), True),
        StructField('Categorie', IntegerType(), True),
        StructField('IDCO', IntegerType(), True),
        StructField('CodeLigneVersion', IntegerType(), True),
        StructField('DebutValidite', StringType(), True),
        StructField('FinValidite', StringType(), True)
    ]
    )
    schemaCourseDate = StructType(
    [
        StructField('Numero', IntegerType(), True),
        StructField('Date', StringType(), True)
    ]
    )
    #endregion

    #region Correspondances
    global schemaCorrespondances

    schemaCorrespondances = StructType(
    [
        StructField('CodeArr1', StringType(), True),
        StructField('IdArr1', IntegerType(), True),
        StructField('CodeArr2', StringType(), True),
        StructField('IdArr2', IntegerType(), True),
        StructField('Dist', IntegerType(), True),
        StructField('Temps', IntegerType(), True),
        StructField('Valide', IntegerType(), True)
    ]
    )
    #endregion
   
def GenerateLignesDF(sparkContext, sourceFilePath):
    dfLigne = extractCSVFile(sparkContext,sourceFilePath + "LIGNE.TXT",schemaLigne,"csv", ";")
    dfReseau = extractCSVFile(sparkContext,sourceFilePath + "RESEAU.TXT",schemaReseau,"csv", ";")
    dfTransporteur = extractCSVFile(sparkContext,sourceFilePath + "TRANSPORTEUR.TXT",schemaTransporteur,"csv", ";")
    dfModeTransport = extractCSVFile(sparkContext,sourceFilePath + "MODETRANSPORT.TXT",schemaModeTransport,"csv", ";") \
                        .withColumn("Ligne",explode(split('Ligne',"[|]") ))
    dfGroupeLigne = extractCSVFile(sparkContext,sourceFilePath + "GROUPELIGNE.TXT",schemaGroupeLigne,"csv", ";")
    
    #renamed columns
    dfLigne = dfLigne \
        .withColumnRenamed("Reseau","CodeReseau") \
        .withColumnRenamed("Transporteur","CodeTransporteur") \
        .withColumnRenamed("GroupeLigne","CodeGroupeLigne")

    dfGroupeLigne = dfGroupeLigne \
        .withColumnRenamed("Code", "CodeGroupeLigne") \
        .withColumnRenamed("Nom", "GroupeLigne")

    dfTransporteur = dfTransporteur \
        .withColumnRenamed("Code","CodeTransporteur") \
        .withColumnRenamed("Nom", "Transporteur")

    dfReseau = dfReseau \
        .withColumnRenamed("Code","CodeReseau") \
        .withColumnRenamed("Nom","Reseau")

    dfModeTransport = dfModeTransport \
        .withColumnRenamed("Ligne","CodeLigne") \
        .withColumnRenamed("Designation","ModeTransport")


    dfLigne = addOriginalFileName(dfLigne)

    #merge Lignes
    df = dfLigne.join(dfGroupeLigne, ["CodeGroupeLigne"], how="left") \
                    .join(dfTransporteur, ["CodeTransporteur"], how="left") \
                    .join(dfReseau, ["CodeReseau"], how="left") \
                    .join(dfModeTransport, ["CodeLigne"], how="left") 

    df = addHashKey(df)
    df = addLoadDate(df)

    return df

def GenerateCheminDF(sparkContext,sourceFilePath):
    dfChemin = extractCSVFile(sparkContext,sourceFilePath + "CHEMIN.TXT",schemaChemin,"csv", ";")
    dfShape = extractCSVFile(sparkContext,sourceFilePath + "SHAPE.TXT",schemaShape,"csv", ";")

    dfChemin = addOriginalFileName(dfChemin)

    #Rename Columns
    dfChemin = dfChemin.withColumnRenamed("Ligne","CodeLigne") \
        .withColumnRenamed("ShapeId","shape_id") \
        .withColumnRenamed("Chemin","CodeChemin") \
        .withColumnRenamed("CodeClient","Direction")


    df = dfChemin.join(dfShape,["shape_id"])

    df = addHashKey(df)
    df = addLoadDate(df)

    return df

def GenerateArretDF(sparkContext, sourceFilePath):
    dfArret = extractCSVFile(sparkContext,sourceFilePath + "ARRET.TXT",schemaArret,"csv", ";")
    dfArretAttribut = extractCSVFile(sparkContext,sourceFilePath + "ARRET_ATTRIBUT.TXT",schemaArretAttribut,"csv", ";")
    dfSchemaArret = extractCSVFile(sparkContext,sourceFilePath + "SCHEMA_ARRET.TXT",schemArretLigne,"csv", ";")
    dfArretLogiqueArret = extractCSVFile(sparkContext,sourceFilePath + "ARRETLOGIQUES_ARRETS.TXT",schemaAL_AR,"csv", ";")
    dfArretLogique = extractCSVFile(sparkContext,sourceFilePath + "ARRETLOGIQUES.TXT",schemaArretLogique,"csv", ";")

    #Rename Columns
    dfArret = dfArret.withColumnRenamed("Code","CodeArret") 
    dfSchemaArret = dfSchemaArret \
                        .withColumnRenamed("Code arret","CodeArret") \
                        .withColumnRenamed("Code Ligne","CodeLigne") \
                        .withColumnRenamed("Numero Ordre","NumeroOrdre") \
                        .withColumnRenamed("Identifiant arret","IdentifiantArret")

    dfArretLogique = dfArretLogique.withColumnRenamed("NOM", "ArretLogique")

    #remove diacritics (\t\r\n\f\v )
    dfArretAttribut = dfArretAttribut.withColumn("Nom",regexp_replace('Nom', '\s', ''))

    #pivot Situation Attribut
    dfArretAttribut = dfArretAttribut \
        .groupBy(["IDAP"]) \
        .pivot("Nom") \
        .agg(first("Valeur"))


    dfArret = addOriginalFileName(dfArret)

    df = dfArret \
            .join(dfSchemaArret, ["CodeArret"]) \
            .join(dfArretAttribut, ["IDAP"]) \
            .join(dfArretLogiqueArret, ["IDAP"], how="left") \
            .join(dfArretLogique, ["ALCODE"], how="left")

    df = addHashKey(df)
    df = addLoadDate(df)

    return df

def GenerateCourseDF(sparkContext,sourceFilePath):
    dfCourse = extractCSVFile(sparkContext, sourceFilePath + "COURSE.TXT",schemaCourse,"csv", ";")
    dfCourseDate = extractCSVFile(sparkContext,sourceFilePath + "COURSE_DATE.TXT",schemaCourseDate,"csv", ";")

    dfCourse = addOriginalFileName(dfCourse)
    
    df = dfCourse.join(dfCourseDate, ["Numero"])

    df = addHashKey(df)
    df = addLoadDate(df)

    return df

def GenerateCorrespondanceDF(sparkContext,sourceFilePath):
    dfCourse = extractCSVFile(sparkContext, sourceFilePath + "CORRESPONDANCE.TXT",schemaCorrespondances,"csv", ";")

    dfCourse = addHashKey(dfCourse)
    dfCourse = addLoadDate(dfCourse)
    dfCourse = addOriginalFileName(dfCourse)
    
    return dfCourse

def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("PT_TH_OFFER")
        v_sourceFilePath= ds['Path']
        v_destinationPath = ds['TargetPath']
    except:
        raise Exception("Failed to load Config")

    define_Structures()

    #Load  from Landing
    dfLigne = GenerateLignesDF(sparkContext,v_sourceFilePath)
    dfChemin = GenerateCheminDF(sparkContext, v_sourceFilePath)
    dfArret = GenerateArretDF(sparkContext, v_sourceFilePath)
    dfCourse = GenerateCourseDF(sparkContext, v_sourceFilePath)
    dfCorrespondance = GenerateCorrespondanceDF(sparkContext, v_sourceFilePath)

    #save Files
    saveDF(dfLigne, filename=v_destinationPath + "LIGNES",source="LIGNES")
    saveDF(dfChemin, filename=v_destinationPath + "CHEMINS",source="CHEMINS")
    saveDF(dfArret, filename=v_destinationPath + "ARRETS",source="ARRETS")
    saveDF(dfCourse, filename=v_destinationPath + "COURSES",source="COURSES")
    saveDF(dfCorrespondance, filename=v_destinationPath + "CORRESPONDANCES",source="CORRESPONDANCES")