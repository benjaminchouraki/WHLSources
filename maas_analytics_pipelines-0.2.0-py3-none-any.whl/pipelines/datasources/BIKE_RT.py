from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile,saveDF
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName

def define_Structures():
    global schemaBikeRT

    schemaBikeRT = StructType([
        StructField('RecordedAtTime', StringType(), True),
        StructField('BikeStationId', IntegerType(), True),
        StructField('BikeStationRef', StringType(), True),
        StructField('BikeStationStatus', StringType(), True),
        StructField('FreeBikes', IntegerType(), True),
        StructField('FreePlaces', IntegerType(), True),
        StructField('SourceTime', StringType(), True),
        StructField('SourceTimeEpoch', StringType(), True),
        StructField('SourceTimeString', StringType(), True),
        StructField('ValidityStart', StringType(), True),
        StructField('ValidityEnd', StringType(), True),
        StructField('AvailabilitySourceType', IntegerType(), True),
        StructField('ProviderRef', StringType(), True)
        ])

def etl(sparkContext, customer):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("BIKE_RT")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "BIKE_RT"
        keys = ds['Keys']
        v_destinationPath =  str(ds['TargetPath']).replace("[CUST]",customer)
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load from Landing
    df = extractJSONFile(sparkContext, v_sourceFilePath + "BIKE.RT.*json",schemaBikeRT)
   
    df = addHashKey(df)
    df = addLoadDate(df)
    df = addOriginalFileName(df)

    #write to Parquet (BIKE_RT)
    saveDF(df, filename=v_destinationPath,source="BIKE_RT")
    
    return df