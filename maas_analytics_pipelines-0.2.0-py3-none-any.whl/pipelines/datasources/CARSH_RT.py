from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile,saveDF
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName


def define_Structures():
    global schemaCARSH

    schemaCARSH = StructType([
        StructField('RecordedAtTime', StringType(), True),
        StructField('CarSharingStationId', IntegerType(), True),
        StructField('CarSharingStationRef', StringType(), True),
        StructField('CarSharingStationStatus', StringType(), True),
        StructField('FreeCars', IntegerType(), True),
        StructField('FreePlaces', IntegerType(), True),
        StructField('Capacity', StringType(), True),
        StructField('SourceTime', StringType(), True),
        StructField('SourceTimeEpoch', StringType(), True),
        StructField('SourceTimeString', StringType(), True),
        StructField('ValidityStart', StringType(), True),
        StructField('ValidityEnd', StringType(), True),
        StructField('AvailabilitySourceType', IntegerType(), True),
        StructField('ProviderRef', StringType(), True)

        ])

def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("CARSH_RT")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "CARSH_RT"
        keys = ds['Keys']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load from Landing
    df = extractJSONFile(sparkContext, v_sourceFilePath + "CARSH.RT.*json",schemaCARSH)
   
    df = addHashKey(df)
    df = addLoadDate(df)
    df = addOriginalFileName(df)

    #write to Parquet (CARSH_RT)
    saveDF(df, filename="output-files/CARSH_RT",source="CARSH_RT")
    
    return df