from pyspark.sql.functions import current_timestamp, date_format, from_unixtime, split, regexp_replace, regexp_extract, udf, input_file_name, first
from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile, saveDF, checkFolderExists
from pipelines.utils.transformations import explodeJSONArray, stringToLong, stringToTimeStamp, addHashKey, addLoadDate, addOriginalFileName
from pipelines.utils.deltaHelper import createTable, generateMergeStatement

def define_Structures():
    global schemaLocationPoint
    global schemaLocationPointDescriptor
    global schemaRoadLink
    global schemaSituationAttribut
    global schemaSituationDescription
    global schemaSituationRecord
    global schemaSituationValidityPeriod

    schemaLocationPoint = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('LPNo', StringType(), True),
            StructField('SRNo', StringType(), True),
            StructField('latitude', StringType(), True),
            StructField('longitude', StringType(), True),
            StructField('direction', StringType(), True),
            StructField('AreaShape', StringType(), True)
                ])
            ))
        ])

    schemaLocationPointDescriptor = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('LPNo', StringType(), True),
            StructField('lang', StringType(), True),
            StructField('descriptorType', StringType(), True),
            StructField('value', StringType(), True)
                ])
            ))
        ])

    schemaRoadLink = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('LPNo', StringType(), True),
            StructField('StreetLinkId', StringType(), True),
            StructField('Direction', StringType(), True),
            StructField('MapObjectId', StringType(), True),
            StructField('Speed', StringType(), True)
                ])
            ))
        ])         

    schemaSituationRecord = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('SituationStatus', StringType(), True),
            StructField('SituationSubType', StringType(), True),
            StructField('idSituation', StringType(), True),
            StructField('idRecord', StringType(), True),
            StructField('version', StringType(), True),
            StructField('dateCreation', StringType(), True),
            StructField('dateVersion', StringType(), True),
            StructField('probability', StringType(), True),
            StructField('CloseTime', StringType(), True),
            StructField('SourceTime', StringType(), True),
            StructField('RecordedAtTime', StringType(), True),
            StructField('ProviderRef', StringType(), True),
                ])
            ))
        ])

    schemaSituationDescription = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('SDNo', StringType(), True),
            StructField('lang', StringType(), True),
            StructField('comment', StringType(), True)
                ])
            ))
        ])

    schemaSituationAttribut = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('SANo', StringType(), True),
            StructField('attributType', StringType(), True),
            StructField('value', StringType(), True)
                ])
            ))
        ])

    schemaSituationValidityPeriod  = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('SRNo', StringType(), True),
            StructField('SVPNo', StringType(), True),
            StructField('startTime', StringType(), True),
            StructField('endTime', StringType(), True)
                ])
            ))
        ])
       
def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("AF_EVENTS")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load  from Landing
    dfLP = extractJSONFile(sparkContext, v_sourceFilePath + "LocationPoint.json",schemaLocationPoint)
    dfLP = explodeJSONArray(dfLP, "Rows")
    dfLPD = extractJSONFile(sparkContext,v_sourceFilePath + "LocationPointDescriptor.json",schemaLocationPointDescriptor)
    dfLPD = explodeJSONArray(dfLPD, "Rows")
    dfRL = extractJSONFile(sparkContext,v_sourceFilePath + "LocationRoadLink.json",schemaRoadLink)
    dfRL = explodeJSONArray(dfRL, "Rows")
    dfSR = extractJSONFile(sparkContext,v_sourceFilePath + "SituationRecord.json",schemaSituationRecord)
    dfSR = explodeJSONArray(dfSR, "Rows")
    dfSA = extractJSONFile(sparkContext,v_sourceFilePath + "SituationAttribut.json",schemaSituationAttribut)
    dfSA = explodeJSONArray(dfSA, "Rows")
    dfSD = extractJSONFile(sparkContext,v_sourceFilePath + "SituationDescription.json",schemaSituationDescription)
    dfSD = explodeJSONArray(dfSD, "Rows")
    dfSVP = extractJSONFile(sparkContext,v_sourceFilePath + "SituationValidityPeriod.json",schemaSituationValidityPeriod)
    dfSVP = explodeJSONArray(dfSVP, "Rows")

    #add Metadata Columns
    dfLP = addOriginalFileName(dfLP)

    #remove diacritics (\t\r\n\f\v )
    dfSA = dfSA.withColumn("attributType",regexp_replace('attributType', '\s', ''))

    #pivot Situation Attribut
    dfSA = dfSA \
        .groupBy(["SRNo","SANo"]) \
        .pivot("AttributType") \
        .agg(first("value"))

    #merge Situation Dataframes  
    dfSituation = dfSR.join(dfSD, ['SRNo'], "inner") \
                    .join(dfSVP, ['SRNo'], "inner") \
                    .join(dfLP,  ['SRNo'], "inner" ) \
                    .join(dfSA,  ['SRNo'], "inner" ) \


    dfSituation = stringToTimeStamp(dfSituation, "RecordedAtTime","dd/MM/yyyy HH:mm:ss")
    dfSituation = stringToLong(dfSituation, "SRNo")

    
    #drop unused columns
    colsToDrop = ['LPNo', 'Direction']
    dfRL = dfRL.drop(*colsToDrop)
    dfLPD = dfLPD.drop(dfLPD.LPNo)
    
    #merge Location DataFrames
    dfLocationPoint = dfLP \
                        .join(dfLPD, ['SRNo'], "inner") \
                        .join(dfRL, ['SRNo'], "inner")
    
    #add Metadata
    dfLocationPoint = addHashKey(dfLocationPoint)
    dfSituation = addLoadDate(dfLocationPoint)

    #write to Parquet (Location / Situation)
    temp_table = "TEMP_LOCATION"
    dfLocationPoint.createOrReplaceTempView(temp_table)
    
    if checkFolderExists(v_destinationPath + "LOCATION") == False:
        saveDF(dfLocationPoint, filename=v_destinationPath + "LOCATION",source="AF_EVENTS")
        createTable(sparkContext, dbName, "LOCATION", v_destinationPath + "LOCATION")
    else:
        createTable(sparkContext, dbName, "LOCATION", v_destinationPath + "LOCATION")
        mergeStatement = generateMergeStatement(dbName, temp_table, "LOCATION","hashkey")
        sparkContext.sql(mergeStatement)

    #saveDF(dfLocationPoint, filename=v_destinationPath + "LOCATION",source="AF_EVENTS")
    #saveDF(dfSituation, filename=v_destinationPath + "SITUATION",source="AF_EVENTS")
