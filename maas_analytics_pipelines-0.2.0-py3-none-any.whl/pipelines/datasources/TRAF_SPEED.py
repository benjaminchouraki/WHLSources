from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pyspark.sql.functions import from_json
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile,saveDF
from pipelines.utils.transformations import explode, addHashKey, addLoadDate, addOriginalFileName

spark = SparkSession.builder.getOrCreate()

def define_Structures():
    global schemaTRSpeed
    global schemaSpeedValidities

    schemaTRSpeed = StructType([
        StructField("RecordedAtTime", StringType(), True),
        StructField("Data", ArrayType(
             StructType([
                StructField('RoadRef', StringType(), True),
                StructField('Direction', IntegerType(), True),
                StructField('SpeedValidities',StringType(),True)
                ])
                ))
        ])

    schemaSpeedValidities = ArrayType(StructType([
        StructField("ValidityPeriod", IntegerType()),
        StructField("Speed", IntegerType()),
        StructField("TrafficStatus", IntegerType())
    ]))

def explodeJSONSpeedValidities(df):
    df = df.withColumn("Rows", explode(df.Data)) \
                .select(['RecordedAtTime', 'Rows.*'])
    
    df = df.withColumn("SpeedValidities", from_json(df.SpeedValidities, schemaSpeedValidities))
    df = df.withColumn("SpeedValidities", explode(df.SpeedValidities)) \
                .select(['RecordedAtTime','RoadRef','Direction', 'SpeedValidities.*'])

    return df

def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("TRAF_SPEED")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "TRAF_SPEED"
        keys = ds['Keys']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load from Landing
    df = extractJSONFile(sparkContext, v_sourceFilePath + "TRAF_SPEED.json",schemaTRSpeed)
    
    df = explodeJSONSpeedValidities(df)

    df = addOriginalFileName(df)
    df = addHashKey(df)
    df = addLoadDate(df)

    #write to Parquet (BIKE_RT)
    saveDF(df, filename=v_destinationPath,source="TRAF_SPEED")

    return df
    