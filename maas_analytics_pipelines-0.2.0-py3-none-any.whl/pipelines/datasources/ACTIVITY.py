from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile,saveDF
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName, explodeJSONArray


def define_Structures():
    global schemaActivity

    schemaActivity = StructType([
        StructField("Journal", ArrayType(
             StructType([
                StructField('Source', StringType(), True),
                StructField('Datetime', StringType(), True),
                StructField('User', StringType(), True),
                StructField('Infos', StringType(), True)
                    ])
                ))
        ])
        
def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("ACTIVITY")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "ACTIVITY"
        keys = ds['Keys']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load from Landing
    df = extractJSONFile(sparkContext, v_sourceFilePath + "ACTIVITY.REF.*json",schemaActivity)
    df = explodeJSONArray(df, "Journal")

    #Add Metadata
    df = addHashKey(df)
    df = addLoadDate(df)
    df = addOriginalFileName(df)

    #write to Parquet (BIKE_RT)
    saveDF(df, filename="output-files/ACTIVITY",source="ACTIVITY")

    return df
    