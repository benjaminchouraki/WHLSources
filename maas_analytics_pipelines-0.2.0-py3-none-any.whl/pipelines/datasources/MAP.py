from pyspark.sql.functions import when, current_timestamp, date_format, from_unixtime, split, explode, regexp_extract, udf, input_file_name, first
from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType, BooleanType
from pipelines.utils.configmanagement import getDatasourcesConfig
from pipelines.utils.fileHelper import checkFileExists, saveDF, extractCSVFile
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName

def define_Structures():
    global schemaCities
    global schemaDataSource
    global schemaStreets
    global schemaStreetsCities
    global schemaStreetsVoirie
    global schemaVoirie

    #regroupement de tronçons de voirie
    schemaStreets = StructType([
        StructField("ID", IntegerType(),True),
        StructField("LINK_ID", IntegerType(),True),
        StructField("ST_NAME", StringType(),True),
        StructField("REF_IN_ID", IntegerType(),True),
        StructField("NREF_IN_ID", IntegerType(),True),
        StructField("FUNC_CLASS", IntegerType(),True),
        StructField("SPEED_CAT", IntegerType(),True),
        StructField("DIR_TRAVEL", StringType(),True),
        StructField("AR_AUTO", StringType(),True),
        StructField("AR_BUS", StringType(),True),
        StructField("AR_PEDEST", StringType(),True),
        StructField("AR_TRAFF", StringType(),True),
        StructField("AR_TAXIS", StringType(),True),
        StructField("PAVED", StringType(),True),
        StructField("PRIVATE", StringType(),True),
        StructField("BRIDGE", StringType(),True),
        StructField("TUNNEL", StringType(),True),
        StructField("TOLLWAY", StringType(),True),
        StructField("FERRY_TYPE", StringType(),True),
        StructField("LONGUEUR", StringType(),True),
        StructField("PENTE", StringType(),True),
        StructField("ALT_DEBUT", StringType(),True),
        StructField("ALT_FIN", StringType(),True),
        StructField("IsBike", IntegerType(),True),
        StructField("IsBikeLane", IntegerType(),True),
        StructField("IsBikeTrack", IntegerType(),True),
        StructField("OsmId", IntegerType(),True),
        StructField("URBAN", StringType(),True),
        StructField("SIDEWALK", StringType(),True),
        StructField("DataSourceId", IntegerType(),True),
        StructField("Accessibility", StringType(),True),
        StructField("ShapeGeog", StringType(),True)
        ])

    #association voiries / villes
    schemaStreetsCities  = StructType([
        StructField("STREETS_ID", IntegerType(),True),
        StructField("CITY_ID", IntegerType(),True)
     ])

    #association rue / tronçons de voirie
    schemaStreetsVoirie  = StructType([
        StructField("VOIE_ID", IntegerType(),True),
        StructField("STREETS_ID", IntegerType(),True)
     ])

    #rue
    schemaVoirie  = StructType([
        StructField("VOIE_ID", IntegerType(),True),
        StructField("VOIE_LIBELLE", StringType(),True),
        StructField("VOIE_LONGUEUR", IntegerType(),True),
        StructField("VOIE_CITY_ID", IntegerType(),True),
        StructField("VOIE_BORNE_DEB", IntegerType(),True),
        StructField("VOIE_BORNE_FIN", IntegerType(),True),
        StructField("VOIE_LATITUDE", StringType(),True),
        StructField("VOIE_LONGITUDE", StringType(),True),
     ])

    schemaCities  = StructType([
        StructField("ID", IntegerType(),True),
        StructField("Shape", StringType(),True),
        StructField("CODINSEE", IntegerType(),True)
     ])

    schemaStreetsCities  = StructType([
        StructField("STREETS_ID", IntegerType(),True),
        StructField("CITY_ID", IntegerType(),True)
     ])

    schemaDataSource  = StructType([
        StructField("Id", IntegerType(),True),
        StructField("Name", StringType(),True),
        StructField("StreetID_MIN", IntegerType(),True),
        StructField("StreetID_MAX", IntegerType(),True),
        StructField("ImportVersion", StringType(),True),
        StructField("ImportDate", StringType(),True),
        StructField("DataVersion", StringType(),True),
        StructField("isNavigation", BooleanType(),True),
        StructField("isAddress", BooleanType(),True),
     ])


def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("MAP")
        v_sourceFilePath= ds['Path']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load  from Landing
    dfStreets = extractCSVFile(sparkContext, v_sourceFilePath + "STREETS.csv",schemaStreets, "csv","\t")
    dfStreetsVoirie = extractCSVFile(sparkContext, v_sourceFilePath + "STREETS_VOIRIE.csv",schemaStreetsVoirie, "csv","\t")
    dfVoirie = extractCSVFile(sparkContext, v_sourceFilePath + "VOIRIE.csv",schemaVoirie, "csv","\t")
    dfStreetCities = extractCSVFile(sparkContext, v_sourceFilePath + "STREETS_CITIES.csv",schemaStreetsCities, "csv","\t")
    dfCities = extractCSVFile(sparkContext, v_sourceFilePath + "CITIES.csv",schemaCities, "csv","\t")
    dfDataSource = extractCSVFile(sparkContext, v_sourceFilePath + "DataSource.csv",schemaDataSource, "csv","\t")

    dfStreets = addOriginalFileName(dfStreets)
    dfCities = addOriginalFileName(dfCities)
    dfVoirie = addOriginalFileName(dfVoirie)

    #Drop useless columns
    dfDataSource = dfDataSource.select(['Id','Name'])
    
    #join Dataframes (STREETS (GR TRONCON) + DS / CITY / VOIRIE)
    dfStreets = dfStreets \
                    .withColumnRenamed("ID","STREETS_ID") \
                    .join(dfDataSource, dfDataSource.Id == dfStreets.DataSourceId, how="left") \
                    .drop('Id') \
                    .join(dfStreetCities, ["STREETS_ID"]) \
                    .join(dfStreetsVoirie, ["STREETS_ID"])


    dfStreets = addHashKey(dfStreets)
    dfStreets = addLoadDate(dfStreets)
    dfCities = addHashKey(dfCities)
    dfCities = addLoadDate(dfCities)
    dfVoirie = addHashKey(dfVoirie)
    dfVoirie = addLoadDate(dfVoirie)

    #write to Parquet (Table STREETS / CITIES / VOIRIE)    
    saveDF(dfStreets, filename=v_destinationPath + "MAP_STREETS",source="MAP")
    saveDF(dfCities, filename= v_destinationPath + "MAP_CITIES",source="MAP")
    saveDF(dfVoirie, filename= v_destinationPath + "MAP_VOIRIES",source="MAP")
