from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile,saveDF, checkFolderExists
from pipelines.utils.transformations import addHashKey, addLoadDate, addOriginalFileName
from pipelines.utils.deltaHelper import MergeDF

def define_Structures():
    global schemaParkRT

    schemaParkRT = StructType([
        StructField('RecordedAtTime', StringType(), True),
        StructField('ParkingId', IntegerType(), True),
        StructField('ParkingRef', StringType(), True),
        StructField('ParkingProviderRef', StringType(), True),
        StructField('ParkingStatus', StringType(), True),
        StructField('CarCapacity', IntegerType(), True),
        StructField('BikeCapacity', IntegerType(), True),
        StructField('MotorbikeCapacity', IntegerType(), True),
        StructField('FreePlaces', IntegerType(), True),
        StructField('OccupiedPlaces', IntegerType(), True),
        StructField('SourceTime', StringType(), True),
        StructField('SourceTimeString', StringType(), True),
        StructField('SourceTimeEpoch', StringType(), True),
        StructField('Comment', StringType(), True),
        StructField('ValidityStart', StringType(), True),
        StructField('ValidityEnd', StringType(), True),
        StructField('AvailabilitySourceType', IntegerType(), True)
        ])

def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("PARK_RT")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "PARK_RT"
        keys = ds['Keys']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load from Landing
    df = extractJSONFile(sparkContext, v_sourceFilePath + "PARK.RT.*json",schemaParkRT)
   
    #Cleaning incorrect rows
    df = df.filter("FreePlaces <= CarCapacity OR ParkingStatus='UNKNOWN'")
    
    df = addHashKey(df)
    df = addLoadDate(df)
    df = addOriginalFileName(df)

    #write to Delta (PARK_RT)
    MergeDF(sparkContext, df, dbName, dataSource, v_destinationPath, keys)
    
    return df