from pyspark.sql.functions import current_timestamp, date_format, from_unixtime, split, regexp_replace, regexp_extract, udf, input_file_name, first
from pyspark.sql.types import StructType, StructField, ArrayType, IntegerType,StringType, DoubleType
from pipelines.utils.configmanagement import getDatasourcesConfig, getConfigSetting
from pipelines.utils.fileHelper import checkFileExists, extractJSONFile, saveDF
from pipelines.utils.transformations import explodeJSONArray, addHashKey, addLoadDate, addOriginalFileName

def define_Structures():
    global schemaLP
    global schemaLPAccess
    global schemaLPAttribut
    global schemaLPInformation
    global schemaLPPointArret

    schemaLP = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('ProviderName', StringType(), True),
            StructField('LP_ID', StringType(), True),
            StructField('LP_IMPORT_ID', StringType(), True),
            StructField('LP_LIBELLE', StringType(), True),
            StructField('CATIDENTIFIANT', StringType(), True),
            StructField('CATNOM', StringType(), True),
            StructField('THM_ID', StringType(), True),
            StructField('THM_LIBELLE', StringType(), True),
            StructField('ADR_ADRESSE', StringType(), True),
            StructField('ADR_SOUSADRESSE', StringType(), True),
            StructField('ADR_COMPLEMENTS', StringType(), True),
            StructField('ADR_NUMRUE', StringType(), True),
            StructField('COM_CODEINSEE', StringType(), True),
            StructField('ADR_CODEPOSTAL', StringType(), True),
            StructField('ADR_VILLE', StringType(), True),
            StructField('ADR_ETAT', StringType(), True),
            StructField('ADR_CEDEX', StringType(), True),
            StructField('ADR_TELEPHONE', StringType(), True),
            StructField('ADR_FAX', StringType(), True),
            StructField('LATITUDE', StringType(), True),
            StructField('LONGITUDE', StringType(), True),
            StructField('LP_SUPPRIMER', StringType(), True),
            StructField('LP_PUBLIER', StringType(), True),
            StructField('DATE_DEBUT_VALIDITE', StringType(), True),
            StructField('DATE_FIN_VALIDITE', StringType(), True)
                ])
            ))
        ])

    schemaLPAccess = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('LP_ID', StringType(), True),
            StructField('ACC_ID', StringType(), True),
            StructField('ACC_LATITUDE', StringType(), True),
            StructField('ACC_LONGITUDE', StringType(), True),
            StructField('ACC_CODE', StringType(), True),
            StructField('ACC_NOM', StringType(), True),
            StructField('TRANO', StringType(), True),
            StructField('ACC_FOOT', StringType(), True),
            StructField('ACC_BIKE', StringType(), True),
            StructField('ACC_ROUTE', StringType(), True),
            StructField('ACC_ACCESSIBILITY', StringType(), True)
                ])
            ))
        ])

    schemaLPAttribut = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('LPATT_ID', StringType(), True),
            StructField('LP_ID', StringType(), True),
            StructField('ATT_NOM', StringType(), True),
            StructField('ATT_VALEUR', StringType(), True),
            StructField('ATT_PARENT_ID', StringType(), True)
                ])
            ))
        ])

    schemaLPInformation = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('LP_ID', StringType(), True),
            StructField('LANGUE', StringType(), True),
            StructField('NAME', StringType(), True),
            StructField('DESCRIPTION', StringType(), True),
            StructField('PERIODE', StringType(), True),
            StructField('EMAIL', StringType(), True),
            StructField('SITE_WEB', StringType(), True)
                ])
            ))
        ])

    schemaLPPointArret = StructType([
        StructField("Name", StringType(),True),
        StructField("Rows", ArrayType(
            StructType([
            StructField('LP_ID', StringType(), True),
            StructField('PA_ID', StringType(), True),
            StructField('VALID', StringType(), True),
            StructField('USERUPDATE', StringType(), True)
                ])
            ))
        ])
        
def etl(sparkContext):
    global v_sourceFilePath 

    try:
        ds = getDatasourcesConfig("POI")
        dbName = getConfigSetting("DatabaseName")
        v_sourceFilePath= ds['Path']
        dataSource = "POI"
        keys = ds['Keys']
        v_destinationPath = ds['TargetPath']
    except:
       raise Exception("Failed to load Config")

    define_Structures()

    #Load  from Landing
    dfLP = extractJSONFile(sparkContext, v_sourceFilePath + "LIEUPUBLIC.json",schemaLP)
    dfLP = explodeJSONArray(dfLP, "Rows")
    dfLP = addOriginalFileName(dfLP)

    dfLPAttribut = extractJSONFile(sparkContext,v_sourceFilePath + "LIEUPUBLIC_ATTRIBUT.json",schemaLPAttribut)
    dfLPAttribut = explodeJSONArray(dfLPAttribut, "Rows")

    #remove diacritics (\t\r\n\f\v )
    dfLPAttribut = dfLPAttribut.withColumn("ATT_NOM",regexp_replace('ATT_NOM', '\s', ''))

    #pivot Situation Attribut
    dfLPAttribut = dfLPAttribut \
        .groupBy(["LPATT_ID","LP_ID"]) \
        .pivot("ATT_NOM") \
        .agg(first("ATT_VALEUR"))

    #Merge LIEU_PUBLIC / LIEU_PUBLIC_ATTRIBUT
    dfLP = dfLP.join(dfLPAttribut, ["LP_ID"], how="left")

    dfLP = addHashKey(dfLP)
    dfLP = addLoadDate(dfLP)

    #write to Parquet (Location / Situation)
    saveDF(dfLP, filename=v_destinationPath,source="POI")

    return dfLP
    